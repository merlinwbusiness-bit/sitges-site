// ============ MODE SWITCH ============
const modeButtons = document.querySelectorAll('.mode-btn');
modeButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const mode = btn.dataset.mode;
    document.body.dataset.mode = mode;
    modeButtons.forEach(b => {
      const active = b === btn;
      b.classList.toggle('active', active);
      b.setAttribute('aria-pressed', active);
    });
  });
});

// ============ AI ASSISTANT ============
const SITGES_CONTEXT = `You are a friendly, knowledgeable local guide for Sitges, Spain (a coastal Catalan town near Barcelona).
Key facts you know:
- Beaches: Platja de Sant Sebastià (family, near old town, calm), Platja de la Bassa Rodona (LGBTQ+, lively),
  Platja del Balmins (clothing-optional cove near the marina), Platja de Terramar (sheltered lagoon, calm, near golf club),
  Platja de la Ribera (family, east side near Sant Bartomeu church), Cala Morisca (quiet hidden cove outside town, Garraf cliffs).
- Culture: Cau Ferrat Museum (Santiago Rusiñol's home/studio), Palau de Maricel (Noucentista palace, weekly guided tours),
  Església de Sant Bartomeu i Santa Tecla (iconic church on the point), the Old Town's white-washed lanes.
- Festivals: Carnival (February, ~10 days, flamboyant parades and parties, one of Spain's longest), 
  Sitges Film Festival (October, world-leading fantasy/horror film festival).
- Food: arròs caldós (brothy seafood rice), fresh local seafood, rooftop restaurants with sea views, 
  Penedès cava country (Codorniu, Freixenet, Gramona, Agustí Torelló Mata, Cava Llopart) a short drive inland.
- Location: 34km southwest of Barcelona, in the Garraf natural park area.

Answer concisely and warmly, like a local giving a friend a tip. Keep responses to 2-4 sentences unless asked for more detail.`;

const setupPanel = document.getElementById('setup-panel');
const chatPanel = document.getElementById('chat-panel');
const apiKeyInput = document.getElementById('api-key');
const saveKeyBtn = document.getElementById('save-key');
const chatLog = document.getElementById('chat-log');
const chatInput = document.getElementById('chat-input');
const chatSend = document.getElementById('chat-send');
const changeKeyBtn = document.getElementById('change-key');

let apiKey = '';

saveKeyBtn.addEventListener('click', () => {
  const key = apiKeyInput.value.trim();
  if (!key) return;
  apiKey = key;
  setupPanel.hidden = true;
  chatPanel.hidden = false;
  chatInput.focus();
});

changeKeyBtn.addEventListener('click', () => {
  apiKey = '';
  apiKeyInput.value = '';
  chatPanel.hidden = true;
  setupPanel.hidden = false;
});

function addMessage(text, sender) {
  const div = document.createElement('div');
  div.className = `chat-msg chat-msg-${sender}`;
  div.textContent = text;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
  return div;
}

async function sendMessage() {
  const question = chatInput.value.trim();
  if (!question || !apiKey) return;

  addMessage(question, 'user');
  chatInput.value = '';
  chatSend.disabled = true;
  const loadingMsg = addMessage('Thinking…', 'ai');

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 400,
        system: SITGES_CONTEXT,
        messages: [{ role: 'user', content: question }]
      })
    });

    const data = await response.json();

    if (data.error) {
      loadingMsg.textContent = `Error: ${data.error.message || 'something went wrong. Check your API key.'}`;
    } else {
      const text = data.content
        .filter(block => block.type === 'text')
        .map(block => block.text)
        .join('\n');
      loadingMsg.textContent = text || 'Sorry, I had trouble answering that — try again?';
    }
  } catch (err) {
    loadingMsg.textContent = 'Connection error. Check your API key and try again.';
  } finally {
    chatSend.disabled = false;
  }
}

chatSend.addEventListener('click', sendMessage);
chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendMessage();
});
